# NavyCraft

compatible with Spigot version 1.8.8  
jars - folder containing jar files of NavyCraft and dependency plugins
